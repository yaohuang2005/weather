                        Weather project

1. Introduction
    This project is to pull current weather report of a specific location from a REST API server.
    
2.Design --- architecture
    The use-case of the project is just to pull weather data.
    So we have a Console listener (a thread) wait for user input geolocation, and send request 
to a blocking queue, then we have a multiple threads (RestReaders) wait on the queue, if there 
are items in the queue, RestReader will pick up the item, send http request to EEST API to get weather.
    
    in the config.properties, you can set thread number, queue size, handerl type, etc.

    Design pattern used:
2.1  Produce-Consumer mode.
            taskQueue                      IContentHandler
                        RestReader1   ---- JsonHandler
InputParser --------->  RestReader2   ---- JsonHandler
                        RestReader3   ---- JsonHandler

2.2  A HandlerFactory is used to build different kind of content processor, so it is easy to support JSON
XML, text response.
2.3  A builder is used to build query string based on Geo, City Name, or Zip code

3. Implementation
    Using Java-8 and Maven

   the packages and classes are:
   common: Constants
   config: Configuration
   console: InputParser, Query
   processor: IContentHandler, JSONConttentHandler, XMLContentHandler, HandlerFactor
   reader: RestReader
   RESTApiAgent  (this is main class)
 
4. Build
    For convenience, I prepared a Dockerfile, so just:

4.1 docker build -t weather:1.0-SNAPSHOT .
4.2 docker run -it weather:1.0-SNAPSHOT /bin/bash

4.3 mvn clean package


5. Test
5.1 Unit test
    I only add a unit test for parse response JSON

5.2 Integration test
After you have a build on target, cd target
cd target
java -cp weather.jar:../lib/*   com.yhuang.RESTApiAgent --config ../etc/config.properties

in terminal, input: 
G 35 139
QUIT

I prepared screenshots for all the steps.

6. TODO
6.1 add unit test
...



