/*
 * Copyright (c) 2022 Yao Huang
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information
 * of Yao Huang. Use of this software is governed by
 * the terms and conditions of the MIT license statement and limited
 * warranty furnished with the software.
 */
package com.yhuang.processor;

import com.yhuang.common.Constants;
import com.yhuang.config.Configuration;
import org.junit.Before;
import org.junit.Test;

import java.util.Properties;

public class JSONContentHandlerTest {
    private Configuration _configuration;

    @Before
    public void setUp() throws Exception {
        Properties props = new Properties();
        props.setProperty(Constants.DATA_KEY, "main");
        _configuration = new Configuration();
        _configuration.setAgentProperties(props);
    }

    @Test
    public void parseResponseTest() throws Exception {
        String jsontext = "{\n" +
                "  \"coord\": {\n" +
                "    \"lon\": 139,\n" +
                "    \"lat\": 35\n" +
                "  },\n" +
                "  \"weather\": [\n" +
                "    {\n" +
                "      \"id\": 804,\n" +
                "      \"main\": \"Clouds\",\n" +
                "      \"description\": \"overcast clouds\",\n" +
                "      \"icon\": \"04d\"\n" +
                "    }\n" +
                "  ],\n" +
                "  \"base\": \"stations\",\n" +
                "  \"main\": {\n" +
                "    \"temp\": 290.8,\n" +
                "    \"feels_like\": 289.93,\n" +
                "    \"temp_min\": 290.8,\n" +
                "    \"temp_max\": 290.8,\n" +
                "    \"pressure\": 1021,\n" +
                "    \"humidity\": 50,\n" +
                "    \"sea_level\": 1021,\n" +
                "    \"grnd_level\": 993\n" +
                "  },\n" +
                "  \"visibility\": 10000,\n" +
                "  \"wind\": {\n" +
                "    \"speed\": 1.78,\n" +
                "    \"deg\": 78,\n" +
                "    \"gust\": 1.9\n" +
                "  },\n" +
                "  \"clouds\": {\n" +
                "    \"all\": 100\n" +
                "  },\n" +
                "  \"dt\": 1652234153,\n" +
                "  \"sys\": {\n" +
                "    \"type\": 1,\n" +
                "    \"id\": 8070,\n" +
                "    \"country\": \"JP\",\n" +
                "    \"sunrise\": 1652211851,\n" +
                "    \"sunset\": 1652261800\n" +
                "  },\n" +
                "  \"timezone\": 32400,\n" +
                "  \"id\": 1851632,\n" +
                "  \"name\": \"Shuzenji\",\n" +
                "  \"cod\": 200\n" +
                "}\n";

        boolean parsed = false;
        try {
            JSONContentHandler handler = new JSONContentHandler();
            handler.setConfig(_configuration);

            parsed = handler.handleData(jsontext);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        assert(parsed);
    }
}
