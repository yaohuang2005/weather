/*
 * Copyright (c) 2022 Yao Huang
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information
 * of Yao Huang. Use of this software is governed by
 * the terms and conditions of the MIT license statement and limited
 * warranty furnished with the software.
 */
package com.yhuang.config;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Configuration {
    private static final Logger _LOGGER = LogManager.getLogger(Configuration.class);

    public String _configFileName;
    public Properties _agentProperties;
    private boolean _valid = false;

    public Configuration() {
    }

    public Configuration(String configFileName) {
        this._configFileName = configFileName;
    }

    public void load(){
        try (InputStream input = new FileInputStream(_configFileName)) {
            _agentProperties = new Properties();
            _agentProperties.load(input);
            _valid = true;
        } catch (IOException ex) {
            _LOGGER.error("cannot load the config file");
            ex.printStackTrace();
        }
    }

    public boolean isValid() {
        return  _valid;
    }

    public void setAgentProperties(Properties agentProperties) {
        _agentProperties = agentProperties;
    }
    public String get(String key, String defaultVal) {
        return _agentProperties.getProperty(key, defaultVal);
    }
}
