/*
 * Copyright (c) 2022 Yao Huang
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information
 * of Yao Huang. Use of this software is governed by
 * the terms and conditions of the MIT license statement and limited
 * warranty furnished with the software.
 */
package com.yhuang.processor;

import com.yhuang.config.Configuration;

public interface IContentHandler {
    boolean handleData(String data);
    void setConfig(Configuration config);
}
