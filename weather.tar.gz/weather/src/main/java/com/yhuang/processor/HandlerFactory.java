/*
 * Copyright (c) 2022 Yao Huang
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information
 * of Yao Huang. Use of this software is governed by
 * the terms and conditions of the MIT license statement and limited
 * warranty furnished with the software.
 */
package com.yhuang.processor;

public class HandlerFactory {

    public HandlerFactory() {
    }

    public IContentHandler create(String type) {
        if (type.equalsIgnoreCase("json")) {
            return new JSONContentHandler();
        } else if (type.equalsIgnoreCase("csv")) {
            return new XMLContentHandler();
        } else {
            return null;
        }
    }
}
