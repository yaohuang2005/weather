/*
 * Copyright (c) 2022 Yao Huang
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information
 * of Yao Huang. Use of this software is governed by
 * the terms and conditions of the MIT license statement and limited
 * warranty furnished with the software.
 */
package com.yhuang.processor;

import com.yhuang.common.Constants;
import com.yhuang.config.Configuration;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.util.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class JSONContentHandler implements IContentHandler {
    private static final Logger _LOGGER = LogManager.getLogger(JSONContentHandler.class);
    private Configuration _config;
    public JSONContentHandler() {
    }

    @Override
    public void setConfig(Configuration config) {
        _config = config;
    }

    /**
     * Retrieves the json raw response from input data and adds back the
     * flattened records to it.
     *
     * @param data The object with contains raw data.
     */
    @Override
    public boolean handleData(String data) {
        boolean parsed = false;
        try {
            JSONParser parser = new JSONParser();
            Object jsonObj = parser.parse(data);
            JSONObject jsonObject = (JSONObject) jsonObj;

            String dataKey = _config.get(Constants.DATA_KEY, Constants.DEFAULT_DATA_KEY);
            Map<String, Object> mainItems = (Map<String, Object>) jsonObject.get(dataKey);

            StringBuilder sb = new StringBuilder();
            for (Map.Entry<String, Object> item : mainItems.entrySet()) {
                String key = item.getKey();
                Object value = item.getValue();
                sb.append(key).append(": ").append(value).append("\n");
            }
            parsed = true;
            System.out.println("The main map in the weather:\n");
            System.out.println(sb);
        } catch (ParseException e) {
            _LOGGER.error(String.format("the json form is wrong: %s ", data), e);
        } catch (Exception e) {
            _LOGGER.error(String.format("error in handling data %s ", data), e);
        }
        return parsed;
    }
}

