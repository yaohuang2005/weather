/*
 * Copyright (c) 2022 Yao Huang
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information
 * of Yao Huang. Use of this software is governed by
 * the terms and conditions of the MIT license statement and limited
 * warranty furnished with the software.
 */
package com.yhuang.reader;

import com.yhuang.config.Configuration;
import com.yhuang.processor.IContentHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.net.ssl.HttpsURLConnection;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.concurrent.BlockingQueue;

import com.yhuang.common.Constants;
import com.yhuang.processor.*;

public class RestReader implements Runnable {
    private static final Logger _LOGGER = LogManager.getLogger(RestReader.class);

    protected BlockingQueue _queue;
    public int _timeIntervalSecs;
    private Configuration _config;
    private boolean _stop;
    private IContentHandler _contentHandler;

    public RestReader(BlockingQueue queue, Configuration configuration) {
        this._queue = queue;
        this._config = configuration;
        _timeIntervalSecs = 1000;
    }

    public void init() {
        _timeIntervalSecs = Integer.parseInt(Constants.DEFAULT_POLL_INTERVAL);
        try {
            _timeIntervalSecs = Integer.parseInt(
                    _config.get(Constants.POLL_INTERVAL_SECS, Constants.DEFAULT_POLL_INTERVAL));
        } catch (NumberFormatException nfe) {
            _LOGGER.warn("invalid value for " + Constants.POLL_INTERVAL_SECS
                    + " using default: " + Constants.DEFAULT_POLL_INTERVAL);
        }

        _stop = false;

        String handler_type = _config.get(Constants.HANDLER_TYPE, Constants.DEFAULT_HANDLER_TYPE);
        HandlerFactory factory = new HandlerFactory();
        _contentHandler = factory.create(handler_type);
        _contentHandler.setConfig(_config);
    }

    public void run() {
        while (true) {
            try {
                String query = (String) _queue.take();
                _LOGGER.info("got input: " + query);
                if (query.equalsIgnoreCase("quit")) {
                    break;
                }

                sendRequest(query);

                // for every api endpoint, we need to sleep, otherwise it will block you access
                Thread.sleep(_timeIntervalSecs);

                if (_stop) {
                    break;
                }
            } catch (InterruptedException ex) {
                _LOGGER.warn("the reader is forced to shutdown by QUIT, exit thread");
                break;
            } catch (Exception ex) {
                _LOGGER.warn("error in the thread, exit the thread");
                break;
            }
        }
    }

    public void setStop() {
        _stop = true;
    }

    public void sendRequest(String query) throws Exception {
        String baseURL = _config.get(Constants.BASE_URL, "https://api.openweathermap.org");
        String endpoint = _config.get(Constants.ENDPOINT, "/data/2.5/weather");
        String appid = _config.get(Constants.APPID, "cf002751564a4c78f5f7ed479f1b9ba3");

        _LOGGER.info("reading");
        StringBuilder fullURL = new StringBuilder();
        fullURL.append(baseURL)
                .append(endpoint)
                .append("?")
                .append(query)
                .append("&appid=")
                .append(appid);

        URL obj = new URL(fullURL.toString());

        HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();

        con.setRequestMethod("GET");

        BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
        String inputLine;

        StringBuffer response = new StringBuffer();
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        String res = response.toString();
        _contentHandler.handleData(res);
    }
}
