/*
 * Copyright (c) 2022 Yao Huang
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information
 * of Yao Huang. Use of this software is governed by
 * the terms and conditions of the MIT license statement and limited
 * warranty furnished with the software.
 */
package com.yhuang.console;

public class Query {
    public final String lat;
    public final String lon;
    public final String cityName;
    public final String stateCode;
    public final String countyCode;
    public final String zipCode;

    private Query(QueryBuilder builder) {
        this.lat = builder.lat;
        this.lon = builder.lon;
        this.cityName = builder.cityName;
        this.stateCode = builder.stateCode;
        this.countyCode = builder.countyCode;
        this.zipCode = builder.zipCode;
    }

    public static class QueryBuilder {
        public String lat;
        public String lon;
        public String cityName;
        public String stateCode;
        public String countyCode;
        public String zipCode;

        public QueryBuilder() {
        }

        public QueryBuilder lat(String lat) {
            this.lat = lat;
            return this;
        }

        public QueryBuilder lon(String lon) {
            this.lon = lon;
            return this;
        }

        public QueryBuilder cityName(String cityName) {
            this.cityName = cityName;
            return this;
        }

        public QueryBuilder stateCode(String stateCode) {
            this.stateCode = stateCode;
            return this;
        }

        public QueryBuilder countyCode(String countyCode) {
            this.countyCode = countyCode;
            return this;
        }

        public QueryBuilder zipCode(String zipCode) {
            this.zipCode = zipCode;
            return this;
        }

        public Query build() {
            return new Query(this);
        }
    }
}