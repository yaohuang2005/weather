/*
 * Copyright (c) 2022 Yao Huang
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information
 * of Yao Huang. Use of this software is governed by
 * the terms and conditions of the MIT license statement and limited
 * warranty furnished with the software.
 */
package com.yhuang.console;

import java.util.Scanner;
import java.util.concurrent.BlockingQueue;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class InputParser implements Runnable {
    private static final Logger _LOGGER = LogManager.getLogger(InputParser.class);

    private BlockingQueue _queue;
    private Scanner _scanner;

    public InputParser(BlockingQueue queue) {
        _queue = queue;
        _scanner = new Scanner(System.in);
    }

/*
        ?lat={lat}&lon={lon}&appid={API key}

        ?q={city name}&appid={API key}
        ?q={city name},{state code}&appid={API key}
        ?q={city name},{state code},{country code}&appid={API key}


        ?id={city id}&appid={API key}

        ?zip={zip code},{country code}&appid={API key}

        current only support lat lon input, such as G 35 139
        G ==> geo
        C ==> city name
        Z ==> zip
 */

    public void run() {
        try {
            System.out.println("Enter Geo lat lon to query weather, (\"QUIT\" to finish)");

            String line;
            while (_scanner.hasNextLine()) {
                line = _scanner.nextLine();
                if (line.equalsIgnoreCase("QUIT")) {
                    break;
                }

                // input format:
                // G 35 139    (geolocation)
                // C New York  (city name)
                // Z 123456    (zip code)
                char firstChar = line.charAt(0);
                if (firstChar == 'G' || firstChar == 'C' || firstChar == 'Z') {
                    String subStr = line.substring(1);  // from second char
                    // now only tested for G 35 139
                    if (firstChar == 'G') {
                        String[] inputs = subStr.trim().split("\\s+");
                        Query query = new Query.QueryBuilder()
                                .lat(inputs[0])
                                .lon(inputs[1])
                                .build();

                        _queue.put("lat=" + query.lat + "&" + "lon=" + query.lon);
                    } else if (firstChar == 'C') {
                        // only for city name
                        String cityName = subStr.trim();
                        Query query = new Query.QueryBuilder()
                                .cityName(cityName)
                                .build();

                        _queue.put("q=" + query.cityName + "&");
                    } else if (firstChar == 'Z') {
                        // TODO
                    }
                } else {
                    _LOGGER.error("wrong input");
                }
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
