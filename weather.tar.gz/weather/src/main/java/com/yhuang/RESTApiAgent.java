/*
 * Copyright (c) 2022 Yao Huang
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information
 * of Yao Huang. Use of this software is governed by
 * the terms and conditions of the MIT license statement and limited
 * warranty furnished with the software.
 */
package com.yhuang;

import com.yhuang.common.Constants;
import com.yhuang.console.InputParser;
import com.yhuang.reader.RestReader;
import org.apache.commons.cli.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.util.concurrent.*;

import com.yhuang.config.Configuration;

public class RESTApiAgent {
    private static final Logger _LOGGER = LogManager.getLogger(RESTApiAgent.class);

    private Configuration _config;
    private RestReader _reader;
    private ExecutorService _executorService;
    private boolean _isRunning;
    public BlockingQueue _queue;
    private final String _configFileName;

    public RESTApiAgent(String configFileName) {
        this._configFileName = configFileName;
    }

    private void init() {
        _config = new Configuration(_configFileName);
        _config.load();

        int queueSize = Integer.valueOf(_config.get(Constants.QUEUE_SIZE, Constants.DEFAULT_QUEUE_SIZE));
        _queue = new ArrayBlockingQueue(queueSize);
        _reader = new RestReader(_queue, _config);
        _reader.init();

        int threadNumber = Integer.valueOf(_config.get(Constants.THREAD_NUMBER, Constants.DEFAULT_THREAD_NUMBER));
        _executorService = Executors.newFixedThreadPool(threadNumber);
//        _executorService = Executors.newSingleThreadExecutor();

    }

    /**
     * Starts reader threads based on the agent config.
     */
    public void start() {
        if (!_config.isValid()) {
            _LOGGER.error("Invalid config received. No agents will be started.");
            return;
        }
        if (!_isRunning) {
            _isRunning = true;
            _executorService.execute(_reader);
        }
        else {
            _LOGGER.warn("Agent already running. No new agent started");
        }
    }

    public void stop() {
        if (_isRunning) {
            _LOGGER.info("Agent stop invoked. Preparing to shutdown agent");
            _reader.setStop();

            _executorService.shutdown();
            try {
                if (!_executorService.awaitTermination(500, TimeUnit.MILLISECONDS)) {
                    _executorService.shutdownNow();
                }
            } catch (InterruptedException e) {
                _executorService.shutdownNow();
            }
        }
        _isRunning = false;
    }


    public static String parseArgs(String[] args) {
        Options options = new Options();
        Option config = new Option("c", "config", true, "config file path");
        config.setRequired(true);
        options.addOption(config);
        CommandLineParser parser = new BasicParser();
        HelpFormatter formatter = new HelpFormatter();
        CommandLine cmd = null;

        try {
            cmd = parser.parse(options, args);
        } catch (ParseException e) {
            System.out.println(e.getMessage());
            formatter.printHelp("utility-name", options);

            System.exit(1);
        }

        String configFile  = cmd.getOptionValue("config");

        return configFile;
    }

    public static void main(String[] args)  throws Exception {
        String fileName = parseArgs(args);
        File configFile = new File(fileName);
        if (!configFile.exists()) {
            System.out.println(String.format("the config file does not exist %s", fileName));
        }

        RESTApiAgent agent = new RESTApiAgent(fileName);
        agent.init();
        agent.start();

        // start console thread
        BlockingQueue queue = agent._queue;
        InputParser inputParser = new InputParser(queue);
        Thread consoleListener = new Thread(inputParser);
        consoleListener.start();

        // wait for console quit, and then stop RestReader threads
        consoleListener.join();
        agent.stop();
        System.out.println("The application exited");
    }
}
