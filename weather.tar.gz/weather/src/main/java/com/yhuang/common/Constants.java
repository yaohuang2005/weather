/*
 * Copyright (c) 2022 Yao Huang
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information
 * of Yao Huang. Use of this software is governed by
 * the terms and conditions of the MIT license statement and limited
 * warranty furnished with the software.
 */
package com.yhuang.common;

public class Constants {
    public static final String DEFAULT_POLL_INTERVAL = "300";
    public static final String POLL_INTERVAL_SECS = "poll_interval_secs";
    public static final String BASE_URL = "base_url";
    public static final String ENDPOINT = "endpoint";
    public static final String APPID = "appid";
    public static final String DATA_KEY = "data_key";
    public static final String DEFAULT_DATA_KEY = "main";

    public static final String HANDLER_TYPE = "handler_type";
    public static final String DEFAULT_HANDLER_TYPE = "json";
    public static final String QUEUE_SIZE = "queue_size";
    public static final String DEFAULT_QUEUE_SIZE = "10";
    public static final String THREAD_NUMBER = "thread_number";
    public static final String DEFAULT_THREAD_NUMBER = "5";
}
